import '../src/assets/styles/Footer.css'

function Footer(){
    return (
        <div className='Footer'>
            <p>Suchiapa</p>
            <p>Carretera Tuxtla Gutierrez. - Portillo Zaragoza Km 21+500</p>
            <p>Col. Las Brisas; Suchiapa, Chiapas. CP.29150. Teléfono: 01961 61 71460</p>
            <p>Suchiapa, Chiapas.</p>
        </div>

    )


}
export default Footer;