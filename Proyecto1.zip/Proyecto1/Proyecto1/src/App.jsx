import Thor from '../src/gods/thor.jsx'
import Hela from '../src/gods/hela.jsx'
import Odin from '../src/gods/Odin.jsx'
import Jormungandr from '../src/gods/jormungandr.jsx'
import Loki from '../src/gods/Loki.jsx'
import Fenrir from '../src/gods/Fenrir.jsx'
import Header from '../src/Header.jsx'
import '../src/assets/styles/index.css'
import Footer from '../src/Footer.jsx'
function App() {
 

  return (
    
    
    <div className="App">
      <Header></Header>
      <Thor></Thor>
      <Odin></Odin>
      <Hela></Hela>
      <Jormungandr></Jormungandr>
      <Loki></Loki>
      <Fenrir></Fenrir>
      <Footer></Footer>
    </div>
  )
}

export default App
