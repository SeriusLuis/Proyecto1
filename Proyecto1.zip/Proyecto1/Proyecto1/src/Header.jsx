import Logo from '../src/assets/images/Logo.png'
import Search from '../src/assets/images/Search.png'
import '../src/assets/styles/Header.css'

function Header(){
    return (
        <div className='Container'>
            <img src={Logo} className='Logo'></img>
            <b className='Title'>La Biblioteca de Odin</b>
            <img src={Search} className='Search'></img>
        </div>
    )
}
export default Header;