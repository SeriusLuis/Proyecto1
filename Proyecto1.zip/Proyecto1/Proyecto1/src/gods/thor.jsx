import Thor from '../assets/images/Thor.jpg';
import '../assets/styles/God.css'

function Gods(){
    return (
       
            <div className = 'GodContainer'>
                <img src={Thor} className='Thor'></img>
                <br></br>
                Thor es el dios de la fuerza y el trueno en la mitologia nordica, donde su poder abarca desde el clima hasta la batalla.
            </div>

        
    )
}

export default Gods;