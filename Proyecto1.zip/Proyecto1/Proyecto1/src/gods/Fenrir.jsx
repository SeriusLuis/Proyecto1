import Fenrir from '../assets/images/Fenrir.jpg';
import '../assets/styles/God.css'

function Gods(){
    return (
       
            <div className = 'GodContainer'>
                <img src={Fenrir} className='Fenrir'></img>
                <br></br>
                Fenrir es un gigantesco lobo de la mitologia nordica que se dice que sera quien acabe con Odin en el Ragnarok.  
                </div>

        
    )
}

export default Gods;