import Loki from '../assets/images/Loki.jpg';
import '../assets/styles/God.css'

function Gods(){
    return (
       
            <div className = 'GodContainer'>
                <img src={Loki} className='Loki'></img>
                <br></br>
                Loki es el dios de los fraudes y el engaño en la mitologia nordica, se dice que se mezclo entre los dioses a pesar de sus actos, hasta que asesino a Balder.            
                </div>

        
    )
}

export default Gods;