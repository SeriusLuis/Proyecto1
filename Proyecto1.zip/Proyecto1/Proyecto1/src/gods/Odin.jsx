import Odin from '../assets/images/Odin.jpg';
import '../assets/styles/God.css'

function Gods(){
    return (
       
            <div className = 'GodContainer'>
                <img src={Odin} className='Odin'></img>
                <br></br>
                Odin es el dios principal de la mitologia nordica, reina sobre la sabiduria, guerra y muerte, aunque se dice que tambien controla la magia, poesia, profecia, victoria y caza.
            </div>

        
    )
}

export default Gods;