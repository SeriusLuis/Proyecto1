import Hela from '../assets/images/Hela.jpg';
import '../assets/styles/God.css'

function Gods(){
    return (
       
            <div className = 'GodContainer'>
                <img src={Hela} className='Hela'></img>
                <br></br>
                Hela es la diosa de los muertos y reina del helheim, el reino de la muerte, en la mitología nordica. Se caracteriza por estar dividida en un lado hermoso y uno decrepito y en putrefaccion.
            </div>

        
    )
}

export default Gods;