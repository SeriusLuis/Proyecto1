import Jormungandr from '../assets/images/Jormungandr.jpg';
import '../assets/styles/God.css'

function Gods(){
    return (
       
            <div className = 'GodContainer'>
                <img src={Jormungandr} className='Jormungandr'></img>
                <br></br>
                Jormungandr es una serpiente de la mitologia nordica. Se dice que era tan grande que podría rodear al mundo y que esperaba al ragnarok para escapar del mar de midgar.
            </div>

        
    )
}

export default Gods;